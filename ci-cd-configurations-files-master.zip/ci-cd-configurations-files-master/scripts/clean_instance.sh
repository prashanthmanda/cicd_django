#!/usr/bin/env bash

sudo rm -rf /home/ubuntu/blogprojectdrf/*